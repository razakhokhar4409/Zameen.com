# Zameen.com
Replicated the zameen.com functionality

This is kind of project that deals with the buying and selling of the Real Estate. In other words it replicates the functionalities of the zameen.com. 
This project file includes entire project along with the sql of the database and the class diagram that can be viewed on star uml. 

***This project has very basic front end which is built on simple console.***
